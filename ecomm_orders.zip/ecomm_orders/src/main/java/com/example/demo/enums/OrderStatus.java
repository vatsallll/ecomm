package com.example.demo.enums;

public enum OrderStatus {

    Pending,
    Placed,
    Shipped,
    Delivered
}
